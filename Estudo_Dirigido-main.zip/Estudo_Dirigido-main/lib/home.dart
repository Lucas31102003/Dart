import 'package:flutter/material.dart';
import 'package:estudo_dirigido/perifericos.dart';
import 'package:estudo_dirigido/pc.dart';

class home extends StatefulWidget
{
  const home({Key? key}) : super(key: key);

  @override
  _homeState createState() => _homeState();
}

class _homeState extends State<home>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
      (
      appBar: new AppBar
        (
          iconTheme: IconThemeData(color: Colors.white),
          title: const Text('FinalMouse', style: TextStyle(color: Colors.black)),
          backgroundColor: Colors.yellow,
        ),
      body: Center
        (
        child: Column
          (
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>
            [
            Image.asset
              (
                "imagens/finalmouse.jpg",
                width: 300,
                height: 200,
              ),
            Text("Finalmouse Starlight-12"),
            //ignore: deprecated_member_use
            RaisedButton
              (
                child: Text("Mouses"),
                color: Colors.amber,
                padding: EdgeInsets.all(25),
                  onPressed:()
                  {
                    Navigator.push(context, MaterialPageRoute
                      (
                        builder: (context) => perifericos()
                      ),
                  );
                  }
              ),
              RaisedButton(
                  child: Text("Onde devemos utiliza-los"),
                  color: Colors.amber,
                  padding: EdgeInsets.all(20),
                  onPressed:(){
                    Navigator.push(context, MaterialPageRoute(
                        builder: (context) => pc()
                    ),
                    );
                  }
              ),
            ],
          ),
        ),
      );
  }
}
