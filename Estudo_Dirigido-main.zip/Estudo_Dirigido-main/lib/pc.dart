import 'package:estudo_dirigido/home.dart';
import 'package:flutter/material.dart';

class pc extends StatefulWidget
{
  const pc({Key? key}) : super(key: key);

  @override
  _pcState createState() => _pcState();
}

class _pcState extends State<pc>
{
  @override
  Widget build(BuildContext context)
  {
    return Scaffold
      (
      appBar: new AppBar
        (
          iconTheme: IconThemeData(color: Colors.white),
          title: const Text('Computadores', style: TextStyle(color: Colors.black)),
          backgroundColor: Colors.yellow,
        ),
      body: Center
        (
        child: Column
          (
          children: <Widget>
          [
            Image.asset
              (
                "imagens/pc1.jpg",
                width: 150,
                height: 100,
              ),

            Image.asset
              (
                "imagens/pc2.jpg",
                width: 150,
                height: 100,
              ),

            Image.asset
              (
                "imagens/placa1.jpg",
                width: 150,
                height: 100,
              ),

            RaisedButton
              (
                child: Text("Retornar"),
                color: Colors.amber,
                padding: EdgeInsets.all(20),
                onPressed:()
                {
                  Navigator.push(context, MaterialPageRoute
                    (
                        builder: (context) => home()
                    ),
                  );
                }
              ),
          ],
          ),
        ),
        );
  }
}