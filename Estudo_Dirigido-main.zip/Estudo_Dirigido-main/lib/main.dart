import 'package:estudo_dirigido/home.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: home(),
  ));
}




