import 'package:desafio_layout/l1.dart';
import 'package:desafio_layout/l2.dart';
import 'package:flutter/material.dart';

void main()
{
  runApp(MyApp(
    home: l1.dart(),
    home: l2.dart(),
  ));
}

